How to use compress:
compress [original_filename] [output_filename]

The output file will have “.mzip” extension automatically

WARNING:
We only guarantee successfull compression of text file
Even with text file, we only guarantee success with alphabetic characters
The compression might not be lossless

Thank you :)
